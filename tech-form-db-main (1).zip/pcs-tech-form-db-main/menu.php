<header class="main-header">
    <div class="brand">
        <a href="index.php">
            Portnov School
        </a>
    </div>
    <nav class="main-nav">
        <ul class="main-nav__items">
            <li class="main-nav__item">
                <a href="add_user_form.php">Add user</a>
            </li>
            <li class="main-nav__item">
                <a href="application.php">Application Form</a>
            </li>
            <li class="main-nav__item">
                <a href="login.php">Login</a>
            </li>
            <li class="main-nav__item">
                <a href="logout.php">Logout</a>
            </li>
        </ul>
    </nav>
</header>